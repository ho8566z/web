export const SESSION = {
    'signInedMemberId': ''
};