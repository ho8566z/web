let systemFlag = true;

const OPENING_NEW_ACCOUNT               = 1;
const DO_DEPOSIT                        = 2;
const DO_WITHDRAW                       = 3;
const PRINT_DEPOSIT_WITHDRAW_HISTORY    = 4;
const SYSTEM_OUT                        = 99;