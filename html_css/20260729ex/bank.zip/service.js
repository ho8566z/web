// 계좌 개설
const openingNewAccount = () => {
    console.log('openingNewAccount() CALLED!!');

    let customerNo = createCustomerNo();
    let accountNumber = createAccountNumber();
    let customerName = prompt('INPUT CUSTOMER NAME!! ');
    let customerPhone = prompt('INPUT CUSTOMER PHONE!! ');

    let customerObj = new Customer(customerNo, customerName, customerPhone, accountNumber);
    customerDB.set(customerNo, customerObj);
    console.log('customerDB: ', customerDB);
}

// 입금
const doDeposit = () => {
    console.log('doDeposit() CALLED!!');

}

// 출금
const doWithDraw = () => {
    console.log('doWithDraw() CALLED!!');

}

// 입/출금 내역
const printDepositWithdrawHistory = () => {
    console.log('printDepositWithdrawHistory() CALLED!!');

}